/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
/* js for resources*/
var button = $('.more-btn')

button.on("click", discoverTwo)

function discoverTwo(){
  // console.log("the function ran.")
// changing the first image
  document.getElementById("image-1").src = "https://www.nycgo.com/images/venues/5870/lockwood-shop_astoria_courtesy__medium.jpg";
  document.getElementById("span1").textContent="Lockwood";
  document.getElementById("link1").href
  ="https://lockwoodshop.com/";

  document.getElementById("image-2").src = "https://media-cdn.tripadvisor.com/media/photo-s/02/d2/fa/ae/the-evolution-store.jpg";
  document.getElementById("span2").textContent="The Evolution Store";
  document.getElementById("link2").href="https://theevolutionstore.com/";

  document.getElementById("image-3").src = "https://images.getbento.com/accounts/f36a0327f9556203538af88b0af9148f/media/images/97185pilar8.jpeg?fit=max&w=1800&auto=format,compress";
  document.getElementById("span3").textContent="Pilar Cuban Eatery";
  document.getElementById("link3").href="https://www.pilarny.com/";

  document.getElementById("image-4").src = "https://images.huffingtonpost.com/2014-07-13-DrielyS9799.jpg";
  document.getElementById("span4").textContent="Babel Fair";
  document.getElementById("link4").href="http://babelfairshowroom.com/";

  document.getElementById("image-5").src = "https://newyork-onmymind.com/wp-content/uploads/2015/05/No-6-store-outside-New-York.jpg";
  document.getElementById("span5").textContent="No.6 Store";
  document.getElementById("link5").href="https://no6store.com/";

  document.getElementById("image-6").src = "https://cdn.shopify.com/s/files/1/0397/6046/1981/files/102669488_3099023743478754_4501857106166586075_n_1800x.jpg?v=1594909150";
  document.getElementById("span6").textContent="Pink Olive";
  document.getElementById("link6").href="https://pinkolive.com/";

  document.getElementById("image-7").src = "https://www.common.com/blog/wp-content/uploads/2019/02/IMG_1807-1024x768.jpg";
  document.getElementById("span7").textContent="Sincerely,Tommy";
  document.getElementById("link7").href="https://sincerelytommy.com/";

  document.getElementById("image-8").src = "https://blankslatepages.s3.amazonaws.com/5654bd553068f-Screen%20Shot%202015-11-24%20at%202.34.04%20PM.png";
  document.getElementById("span8").textContent="Front General Store";
  document.getElementById("link8").href="https://frontgeneralstore.com/";

  document.getElementById("image-9").src = "https://cdn.shopify.com/s/files/1/0212/1060/files/F_M_Office_4349_720x.jpg?v=1527277289";
  document.getElementById("span9").textContent="Fredericks and Mae";
  document.getElementById("link9").href="https://fredericksandmae.com/";
}